# MentorMatch — Backend (Entra ID + MFA model)

Fresh application replacing the earlier magic-link design. All users — external
alumni mentors (Entra B2B guests) and internal staff — authenticate through
Microsoft Entra ID. **MFA is enforced by Conditional Access policies in the
tenant, not by this application**: by the time a token reaches this API, the
MFA challenge has already been satisfied. The API's job is token validation
(signature, audience, expiry) and role-based authorization.

## What's included

| Area | Where |
|---|---|
| Entra token validation + role policies | `Program.cs` |
| Entities incl. Match (with DB-level lock) and ActionAuditLog | `Models/Entities.cs` |
| DbContext, filtered unique index enforcing one match per mentee | `Data/AppDbContext.cs` |
| Excel import (mentee + mentor) with per-row error reporting, Excel/CSV export | `Services/ExcelAndAuditServices.cs` |
| Staff endpoints: upload, approve, withdraw match, download reports, audit view | `Endpoints/StaffEndpoints.cs` |
| Mentor endpoints: browse/filter, select (409 on race), my-match | `Endpoints/MentorEndpoints.cs` |

## Entra setup required (one-time, via DTS)

1. **App registration** for this API. Expose an application ID URI
   (`api://<client-id>`), and define three **app roles**:
   - `Careers.Staff`
   - `Alumni.Staff`
   - `Mentor`
2. Assign Entra **security groups** to the two staff roles (existing joiner/
   leaver processes then govern access automatically).
3. Mentors are invited as **B2B guests** each cycle and assigned the `Mentor`
   role (this can be scripted from the same uploaded email list).
4. **Conditional Access policies**:
   - Require MFA for guest users, scoped to this app registration.
   - (Staff MFA presumably already enforced tenant-wide.)
   - Recommended: short sign-in frequency for guests.
5. Tenant external-collaboration settings: guest access restricted to own
   directory objects; guest invitations restricted to designated roles.

## Two-layer mentor authorization (important)

A valid guest token with the `Mentor` role is **necessary but not sufficient**.
Every mentor endpoint also resolves the token's email claim against the
mentor list uploaded by the Alumni Office for the currently open cycle
(`CurrentMentor` in `MentorEndpoints.cs`). The uploaded list is the source of
truth for who is a mentor *this cycle* — a guest from a previous year with a
still-valid token but absent from this year's upload gets HTTP 403.

## The selection lock

One mentee can be matched at most once (excluding withdrawn matches). This is
enforced by a **filtered unique index** on `Matches.MenteeId`
(`WHERE Status <> 'withdrawn'`). If two mentors select the same mentee
simultaneously, the database commits exactly one insert; the loser receives
HTTP 409 with a clear message. No application-level check can be raced past
this — the guarantee lives in the database.

## Auditing

- **Inside the app**: `ActionAuditLog` records every upload (with row counts),
  eligibility approval, selection, withdrawal, and report download — actor
  (token's `preferred_username`), action, target, detail, IP, timestamp.
  The audit row is saved in the same `SaveChanges` as the action itself, so an
  action cannot succeed without its audit entry.
- **Sign-ins/MFA**: Entra ID's own sign-in logs cover every authentication,
  including guests, with MFA result, device, and location — no application
  code required.

## Excel file formats

**Mentee upload** (first row = headers):
`Name | Course | Faculty | Email | Bio | Categories`

**Mentor upload**:
`Name | Email | Phone | CareerArea | Bio | Categories`

`Categories` is semicolon-separated (e.g. `Engineering; Data Science`);
unknown categories are created automatically on import. Rejected rows are
returned in the upload response with reasons — nothing is skipped silently.

## Endpoints

| Method | Route | Role |
|---|---|---|
| POST | `/api/staff/mentees/upload/{cycleId}` | Careers.Staff |
| GET | `/api/staff/mentees/pending/{cycleId}` | Careers.Staff |
| POST | `/api/staff/mentees/{menteeId}/approve` | Careers.Staff |
| POST | `/api/staff/mentors/upload/{cycleId}` | Alumni.Staff |
| POST | `/api/staff/mentors/matches/{matchId}/withdraw` | Alumni.Staff |
| GET | `/api/staff/reports/matches/{cycleId}.xlsx` | Alumni.Staff |
| GET | `/api/staff/reports/unmatched/{cycleId}.xlsx` | Alumni.Staff |
| GET | `/api/staff/reports/mailchimp/{cycleId}.csv` | Alumni.Staff |
| GET | `/api/staff/audit?take=100` | Any staff |
| GET | `/api/mentor/mentees?category=&search=` | Mentor |
| GET | `/api/mentor/my-match` | Mentor |
| POST | `/api/mentor/select/{menteeId}` | Mentor |

## Running locally

1. Open `backend/MentorMatch.sln` in Visual Studio 2022 (NuGet restores automatically).
2. Fill `AzureAd` values in `appsettings.json` (needs the DTS app registration).
3. Package Manager Console: `Add-Migration InitialCreate` then `Update-Database`
   (uses LocalDB via `appsettings.Development.json`).
4. F5. Endpoints require a valid bearer token — for local testing before the
   app registration exists, temporarily relax `RequireAuthorization` or use a
   test tenant.

## Not included (deliberate)

- Match-confirmation email (Feature 4) — send via Microsoft Graph once the
  sender-mailbox app permission is confirmed with DTS; the earlier project's
  `GraphEmailService` pattern applies directly.
- Cycle close-out job — under the Entra model, ending access = disabling the
  guest accounts / removing the app role (a tenant action, optionally
  scripted), not an application job. `Mentor.IsActive` and cycle dates still
  gate the API as a second layer.
- Frontend — the earlier React scaffold applies, swapping the request-link page
  for an MSAL (Microsoft Authentication Library) login redirect.
