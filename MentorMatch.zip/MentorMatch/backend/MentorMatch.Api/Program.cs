using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using MentorMatch.Api.Data;
using MentorMatch.Api.Endpoints;
using MentorMatch.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// -----------------------------------------------------------------
// Authentication: EVERY token is validated against Entra ID.
// MFA itself is enforced by the tenant's Conditional Access policies
// (staff via existing policy, mentors via the guest policy scoped to
// this app) -- by the time a token reaches us, MFA already happened.
// This app's job is only: validate signature/audience/expiry, then
// authorize by role.
// -----------------------------------------------------------------
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

builder.Services.AddAuthorization(options =>
{
    // Staff roles come from Entra security-group-mapped app roles.
    // DTS assigns the groups to the app registration's roles once.
    options.AddPolicy("CareersStaff", p => p.RequireRole("Careers.Staff"));
    options.AddPolicy("AlumniStaff", p => p.RequireRole("Alumni.Staff"));
    options.AddPolicy("AnyStaff", p => p.RequireRole("Careers.Staff", "Alumni.Staff"));

    // Mentors are Entra B2B guests with the Mentor app role. Note: holding a
    // valid token is necessary but NOT sufficient -- endpoints additionally
    // resolve the email claim against the uploaded mentor list for the open
    // cycle, so the Alumni Office's upload stays the source of truth.
    options.AddPolicy("Mentor", p => p.RequireRole("Mentor"));
});

builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddScoped<AuditService>();
builder.Services.AddScoped<ExcelService>();

// CORS only needed during separate frontend dev; in production the React
// build is served same-origin from wwwroot.
builder.Services.AddCors(o => o.AddPolicy("Dev", p => p
    .WithOrigins(builder.Configuration["App:DevClientUrl"] ?? "http://localhost:5173")
    .AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

var app = builder.Build();

app.UseHttpsRedirection();

if (app.Environment.IsDevelopment())
    app.UseCors("Dev");

app.UseAuthentication();
app.UseAuthorization();

app.MapStaffEndpoints();
app.MapMentorEndpoints();

if (!app.Environment.IsDevelopment())
{
    app.UseDefaultFiles();
    app.UseStaticFiles();
    app.MapFallbackToFile("index.html");
}

app.Run();
