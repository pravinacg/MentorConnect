using Microsoft.EntityFrameworkCore;
using MentorMatch.Api.Data;
using MentorMatch.Api.Services;

namespace MentorMatch.Api.Endpoints;

public static class MentorEndpoints
{
    public static void MapMentorEndpoints(this WebApplication app)
    {
        var g = app.MapGroup("/api/mentor").RequireAuthorization("Mentor");

        // Browse eligible, unmatched mentees -- with optional category/keyword filters.
        // Deliberately excludes mentee email/contact: those are only released in the
        // match confirmation, never at browse time (data minimisation).
        g.MapGet("/mentees", async (
            string? category, string? search, AppDbContext db, HttpContext ctx) =>
        {
            var mentor = await CurrentMentor(db, ctx);
            if (mentor is null) return Results.Forbid();

            var query = db.Mentees
                .Where(m => m.CycleId == mentor.CycleId && m.IsEligible
                            && !m.Matches.Any(x => x.Status == "confirmed"));

            if (!string.IsNullOrEmpty(category))
                query = query.Where(m => m.Categories.Any(c => c.Category.Label == category));

            if (!string.IsNullOrEmpty(search))
                query = query.Where(m => m.Name.Contains(search)
                                      || m.Course.Contains(search)
                                      || (m.Bio != null && m.Bio.Contains(search)));

            var results = await query
                .Select(m => new
                {
                    m.Id,
                    m.Name,
                    m.Course,
                    m.Faculty,
                    m.Bio,
                    Categories = m.Categories.Select(c => c.Category.Label)
                })
                .ToListAsync();

            return Results.Ok(results);
        });

        // Has this mentor already selected someone?
        g.MapGet("/my-match", async (AppDbContext db, HttpContext ctx) =>
        {
            var mentor = await CurrentMentor(db, ctx);
            if (mentor is null) return Results.Forbid();

            var match = await db.Matches
                .Include(m => m.Mentee)
                .Where(m => m.MentorId == mentor.Id && m.Status == "confirmed")
                .Select(m => new { m.Id, MenteeName = m.Mentee.Name, m.MatchedAt })
                .FirstOrDefaultAsync();

            return Results.Ok(match);
        });

        // Select a mentee. The lock is the database's filtered unique index on
        // Matches.MenteeId -- if two mentors select the same mentee simultaneously,
        // exactly one INSERT commits; the other throws a unique violation we catch
        // and translate into 409 Conflict. No app-level check can be raced past this.
        g.MapPost("/select/{menteeId:guid}", async (
            Guid menteeId, AppDbContext db, AuditService audit, HttpContext ctx) =>
        {
            var mentor = await CurrentMentor(db, ctx);
            if (mentor is null) return Results.Forbid();

            // One selection per mentor
            var alreadyMatched = await db.Matches
                .AnyAsync(m => m.MentorId == mentor.Id && m.Status == "confirmed");
            if (alreadyMatched)
                return Results.Conflict("You have already selected a mentee.");

            var mentee = await db.Mentees
                .FirstOrDefaultAsync(m => m.Id == menteeId
                                       && m.CycleId == mentor.CycleId
                                       && m.IsEligible);
            if (mentee is null) return Results.NotFound();

            db.Matches.Add(new Models.Match { MentorId = mentor.Id, MenteeId = mentee.Id });
            audit.Record(Email(ctx), "mentee_selected", mentee.Id, $"by mentor {mentor.Id}", Ip(ctx));

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                // Unique index violation: another mentor's selection committed first
                return Results.Conflict("This mentee was just selected by another mentor.");
            }

            return Results.Ok(new { menteeName = mentee.Name });
        });
    }

    // The token's email claim is the mentor's identity -- resolved against the
    // uploaded mentor list for the currently open cycle. A valid Entra guest token
    // whose email is NOT on the uploaded list gets nothing: the upload list remains
    // the source of truth for who is a mentor this cycle.
    private static async Task<Models.Mentor?> CurrentMentor(AppDbContext db, HttpContext ctx)
    {
        var email = Email(ctx);
        if (string.IsNullOrEmpty(email)) return null;

        var now = DateTimeOffset.UtcNow;
        return await db.Mentors
            .Include(m => m.Cycle)
            .FirstOrDefaultAsync(m =>
                m.Email.ToLower() == email.ToLower()
                && m.IsActive
                && m.Cycle.OpensAt <= now && m.Cycle.ClosesAt > now);
    }

    private static string Email(HttpContext ctx) =>
        ctx.User.FindFirst("preferred_username")?.Value
        ?? ctx.User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value
        ?? "";

    private static string? Ip(HttpContext ctx) => ctx.Connection.RemoteIpAddress?.ToString();
}
