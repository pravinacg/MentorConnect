using Microsoft.EntityFrameworkCore;
using MentorMatch.Api.Data;
using MentorMatch.Api.Services;

namespace MentorMatch.Api.Endpoints;

public static class StaffEndpoints
{
    public static void MapStaffEndpoints(this WebApplication app)
    {
        var careers = app.MapGroup("/api/staff/mentees").RequireAuthorization("CareersStaff");
        var alumni = app.MapGroup("/api/staff/mentors").RequireAuthorization("AlumniStaff");
        var reports = app.MapGroup("/api/staff/reports").RequireAuthorization("AlumniStaff");

        // ---------------- Careers Service ----------------

        // Upload the mentee Excel file (multipart/form-data, field name "file")
        careers.MapPost("/upload/{cycleId:guid}", async (
            Guid cycleId, IFormFile file,
            AppDbContext db, ExcelService excel, AuditService audit, HttpContext ctx) =>
        {
            if (file.Length == 0) return Results.BadRequest("Empty file.");

            await using var stream = file.OpenReadStream();
            var result = excel.ReadMentees(stream, cycleId, db);

            audit.Record(User(ctx), "mentee_upload", cycleId,
                $"Imported {result.Imported} mentees, {result.RowErrors.Count} rows rejected", Ip(ctx));
            await db.SaveChangesAsync();

            return Results.Ok(new { result.Imported, result.RowErrors });
        }).DisableAntiforgery();

        // Approve a mentee as eligible (makes them visible to mentors)
        careers.MapPost("/{menteeId:guid}/approve", async (
            Guid menteeId, AppDbContext db, AuditService audit, HttpContext ctx) =>
        {
            var mentee = await db.Mentees.FindAsync(menteeId);
            if (mentee is null) return Results.NotFound();

            mentee.IsEligible = true;
            audit.Record(User(ctx), "mentee_approved", menteeId, null, Ip(ctx));
            await db.SaveChangesAsync();

            return Results.Ok();
        });

        // Pending-review list for the Careers admin screen
        careers.MapGet("/pending/{cycleId:guid}", async (Guid cycleId, AppDbContext db) =>
            await db.Mentees
                .Where(m => m.CycleId == cycleId && !m.IsEligible)
                .Select(m => new { m.Id, m.Name, m.Course, m.Faculty, m.Bio })
                .ToListAsync());

        // ---------------- Alumni Office ----------------

        // Upload the mentor Excel file
        alumni.MapPost("/upload/{cycleId:guid}", async (
            Guid cycleId, IFormFile file,
            AppDbContext db, ExcelService excel, AuditService audit, HttpContext ctx) =>
        {
            if (file.Length == 0) return Results.BadRequest("Empty file.");

            await using var stream = file.OpenReadStream();
            var result = excel.ReadMentors(stream, cycleId, db);

            audit.Record(User(ctx), "mentor_upload", cycleId,
                $"Imported {result.Imported} mentors, {result.RowErrors.Count} rows rejected", Ip(ctx));
            await db.SaveChangesAsync();

            return Results.Ok(new { result.Imported, result.RowErrors });
        }).DisableAntiforgery();

        // Withdraw a match (the post-match-breakdown scenario): mentee returns to the pool
        alumni.MapPost("/matches/{matchId:guid}/withdraw", async (
            Guid matchId, AppDbContext db, AuditService audit, HttpContext ctx) =>
        {
            var match = await db.Matches.FindAsync(matchId);
            if (match is null) return Results.NotFound();

            match.Status = "withdrawn";
            audit.Record(User(ctx), "match_withdrawn", matchId, null, Ip(ctx));
            await db.SaveChangesAsync();

            return Results.Ok();
        });

        // ---------------- Reports (downloads) ----------------

        reports.MapGet("/matches/{cycleId:guid}.xlsx", async (
            Guid cycleId, AppDbContext db, ExcelService excel, AuditService audit, HttpContext ctx) =>
        {
            var matches = await db.Matches
                .Include(m => m.Mentor).Include(m => m.Mentee)
                .Where(m => m.Mentor.CycleId == cycleId && m.Status == "confirmed")
                .ToListAsync();

            audit.Record(User(ctx), "report_downloaded", cycleId, $"matches ({matches.Count} rows)", Ip(ctx));
            await db.SaveChangesAsync();

            return Results.File(excel.WriteMatchesWorkbook(matches),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "matches.xlsx");
        });

        reports.MapGet("/unmatched/{cycleId:guid}.xlsx", async (
            Guid cycleId, AppDbContext db, ExcelService excel, AuditService audit, HttpContext ctx) =>
        {
            var unmatchedMentors = await db.Mentors
                .Where(m => m.CycleId == cycleId && !m.Matches.Any(x => x.Status == "confirmed"))
                .ToListAsync();

            var unmatchedMentees = await db.Mentees
                .Where(m => m.CycleId == cycleId && m.IsEligible
                            && !m.Matches.Any(x => x.Status == "confirmed"))
                .ToListAsync();

            audit.Record(User(ctx), "report_downloaded", cycleId,
                $"unmatched ({unmatchedMentors.Count} mentors, {unmatchedMentees.Count} mentees)", Ip(ctx));
            await db.SaveChangesAsync();

            return Results.File(excel.WriteUnmatchedWorkbook(unmatchedMentors, unmatchedMentees),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "unmatched.xlsx");
        });

        reports.MapGet("/mailchimp/{cycleId:guid}.csv", async (
            Guid cycleId, AppDbContext db, ExcelService excel, AuditService audit, HttpContext ctx) =>
        {
            var matchedMentors = await db.Mentors
                .Where(m => m.CycleId == cycleId && m.Matches.Any(x => x.Status == "confirmed"))
                .ToListAsync();

            audit.Record(User(ctx), "report_downloaded", cycleId, $"mailchimp ({matchedMentors.Count} rows)", Ip(ctx));
            await db.SaveChangesAsync();

            return Results.File(excel.WriteMailchimpCsv(matchedMentors), "text/csv", "mailchimp-list.csv");
        });

        // Audit log viewer (both staff roles can read)
        app.MapGet("/api/staff/audit", async (AppDbContext db, int take) =>
            await db.ActionAuditLogs
                .OrderByDescending(a => a.CreatedAt)
                .Take(take is > 0 and <= 500 ? take : 100)
                .ToListAsync())
            .RequireAuthorization("AnyStaff");
    }

    private static string User(HttpContext ctx) =>
        ctx.User.FindFirst("preferred_username")?.Value
        ?? ctx.User.Identity?.Name
        ?? "unknown";

    private static string? Ip(HttpContext ctx) => ctx.Connection.RemoteIpAddress?.ToString();
}
