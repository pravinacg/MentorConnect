using Microsoft.EntityFrameworkCore;
using MentorMatch.Api.Models;

namespace MentorMatch.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<MatchingCycle> Cycles => Set<MatchingCycle>();
    public DbSet<Mentor> Mentors => Set<Mentor>();
    public DbSet<Mentee> Mentees => Set<Mentee>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<MentorCategory> MentorCategories => Set<MentorCategory>();
    public DbSet<MenteeCategory> MenteeCategories => Set<MenteeCategory>();
    public DbSet<Match> Matches => Set<Match>();
    public DbSet<ActionAuditLog> ActionAuditLogs => Set<ActionAuditLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Mentor>().HasIndex(m => new { m.Email, m.CycleId }).IsUnique();
        b.Entity<Category>().HasIndex(c => c.Label).IsUnique();

        b.Entity<MentorCategory>().HasKey(x => new { x.MentorId, x.CategoryId });
        b.Entity<MenteeCategory>().HasKey(x => new { x.MenteeId, x.CategoryId });

        // THE critical constraint: at most one non-withdrawn match per mentee,
        // enforced by the database itself. A filtered unique index means two
        // concurrent selections of the same mentee cannot both commit -- the
        // second insert fails at the database level regardless of app logic.
        b.Entity<Match>()
            .HasIndex(m => m.MenteeId)
            .IsUnique()
            .HasFilter("[Status] <> 'withdrawn'");

        b.Entity<Match>()
            .HasOne(m => m.Mentor)
            .WithMany(mentor => mentor.Matches)
            .HasForeignKey(m => m.MentorId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Match>()
            .HasOne(m => m.Mentee)
            .WithMany(mentee => mentee.Matches)
            .HasForeignKey(m => m.MenteeId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<ActionAuditLog>().HasIndex(a => a.CreatedAt);
    }
}
