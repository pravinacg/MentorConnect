using ClosedXML.Excel;
using MentorMatch.Api.Data;
using MentorMatch.Api.Models;

namespace MentorMatch.Api.Services;

// ---------------------------------------------------------------
// Audit: one call per side-effecting action, from every endpoint.
// ---------------------------------------------------------------
public class AuditService
{
    private readonly AppDbContext _db;
    public AuditService(AppDbContext db) => _db = db;

    public void Record(string performedBy, string actionType, Guid? targetId, string? detail, string? ip)
    {
        _db.ActionAuditLogs.Add(new ActionAuditLog
        {
            PerformedBy = performedBy,
            ActionType = actionType,
            TargetId = targetId,
            Detail = detail,
            IpAddress = ip
        });
        // SaveChanges is called by the endpoint alongside its own changes,
        // so the audit row commits in the SAME transaction as the action itself --
        // an action can never succeed without its audit row, or vice versa.
    }
}

// ---------------------------------------------------------------
// Excel import/export via ClosedXML.
// Import result carries per-row errors so uploads are never silent.
// ---------------------------------------------------------------
public record ImportResult(int Imported, List<string> RowErrors);

public class ExcelService
{
    // Expected mentee columns (row 1 = headers): Name | Course | Faculty | Email | Bio | Categories
    // Categories cell is semicolon-separated, e.g. "Engineering; Data Science"
    public ImportResult ReadMentees(Stream file, Guid cycleId, AppDbContext db)
    {
        var errors = new List<string>();
        var imported = 0;

        using var wb = new XLWorkbook(file);
        var ws = wb.Worksheet(1);
        var rows = ws.RangeUsed()?.RowsUsed().Skip(1) ?? Enumerable.Empty<IXLRangeRow>();

        foreach (var row in rows)
        {
            var rowNum = row.RowNumber();
            var name = row.Cell(1).GetString().Trim();
            var course = row.Cell(2).GetString().Trim();
            var faculty = row.Cell(3).GetString().Trim();
            var email = row.Cell(4).GetString().Trim();
            var bio = row.Cell(5).GetString().Trim();
            var categoriesRaw = row.Cell(6).GetString().Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(course))
            {
                errors.Add($"Row {rowNum}: missing required Name or Course -- skipped.");
                continue;
            }

            var mentee = new Mentee
            {
                Name = name,
                Course = course,
                Faculty = string.IsNullOrEmpty(faculty) ? null : faculty,
                Email = string.IsNullOrEmpty(email) ? null : email,
                Bio = string.IsNullOrEmpty(bio) ? null : bio,
                CycleId = cycleId,
                IsEligible = false   // eligible only after Careers Service approves
            };

            AttachCategories(categoriesRaw, db,
                cat => mentee.Categories.Add(new MenteeCategory { Mentee = mentee, Category = cat }));

            db.Mentees.Add(mentee);
            imported++;
        }

        return new ImportResult(imported, errors);
    }

    // Expected mentor columns: Name | Email | Phone | CareerArea | Bio | Categories
    public ImportResult ReadMentors(Stream file, Guid cycleId, AppDbContext db)
    {
        var errors = new List<string>();
        var imported = 0;
        var seenEmails = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        using var wb = new XLWorkbook(file);
        var ws = wb.Worksheet(1);
        var rows = ws.RangeUsed()?.RowsUsed().Skip(1) ?? Enumerable.Empty<IXLRangeRow>();

        foreach (var row in rows)
        {
            var rowNum = row.RowNumber();
            var name = row.Cell(1).GetString().Trim();
            var email = row.Cell(2).GetString().Trim();
            var phone = row.Cell(3).GetString().Trim();
            var careerArea = row.Cell(4).GetString().Trim();
            var bio = row.Cell(5).GetString().Trim();
            var categoriesRaw = row.Cell(6).GetString().Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || !email.Contains('@'))
            {
                errors.Add($"Row {rowNum}: missing/invalid Name or Email -- skipped.");
                continue;
            }
            if (!seenEmails.Add(email))
            {
                errors.Add($"Row {rowNum}: duplicate email '{email}' within file -- skipped.");
                continue;
            }

            var mentor = new Mentor
            {
                Name = name,
                Email = email,
                ContactPhone = string.IsNullOrEmpty(phone) ? null : phone,
                CareerArea = string.IsNullOrEmpty(careerArea) ? null : careerArea,
                Bio = string.IsNullOrEmpty(bio) ? null : bio,
                CycleId = cycleId
            };

            AttachCategories(categoriesRaw, db,
                cat => mentor.Categories.Add(new MentorCategory { Mentor = mentor, Category = cat }));

            db.Mentors.Add(mentor);
            imported++;
        }

        return new ImportResult(imported, errors);
    }

    private static void AttachCategories(string raw, AppDbContext db, Action<Category> attach)
    {
        if (string.IsNullOrEmpty(raw)) return;
        foreach (var label in raw.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            // Find-or-create against both the DB and anything added earlier in this same import
            var cat = db.Categories.Local.FirstOrDefault(c => c.Label.Equals(label, StringComparison.OrdinalIgnoreCase))
                      ?? db.Categories.FirstOrDefault(c => c.Label == label)
                      ?? AddNew(db, label);
            attach(cat);
        }
    }

    private static Category AddNew(AppDbContext db, string label)
    {
        var cat = new Category { Label = label };
        db.Categories.Add(cat);
        return cat;
    }

    // -----------------------------------------------------------
    // Exports
    // -----------------------------------------------------------
    public byte[] WriteMatchesWorkbook(IEnumerable<Match> matches)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Matches");
        ws.Cell(1, 1).Value = "Mentor name";
        ws.Cell(1, 2).Value = "Mentor email";
        ws.Cell(1, 3).Value = "Mentor career area";
        ws.Cell(1, 4).Value = "Mentee name";
        ws.Cell(1, 5).Value = "Mentee course";
        ws.Cell(1, 6).Value = "Mentee email";
        ws.Cell(1, 7).Value = "Status";
        ws.Cell(1, 8).Value = "Matched at";

        var r = 2;
        foreach (var m in matches)
        {
            ws.Cell(r, 1).Value = m.Mentor.Name;
            ws.Cell(r, 2).Value = m.Mentor.Email;
            ws.Cell(r, 3).Value = m.Mentor.CareerArea ?? "";
            ws.Cell(r, 4).Value = m.Mentee.Name;
            ws.Cell(r, 5).Value = m.Mentee.Course;
            ws.Cell(r, 6).Value = m.Mentee.Email ?? "";
            ws.Cell(r, 7).Value = m.Status;
            ws.Cell(r, 8).Value = m.MatchedAt.UtcDateTime;
            r++;
        }
        ws.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    public byte[] WriteUnmatchedWorkbook(IEnumerable<Mentor> mentors, IEnumerable<Mentee> mentees)
    {
        using var wb = new XLWorkbook();

        var wsMentors = wb.Worksheets.Add("Unmatched mentors");
        wsMentors.Cell(1, 1).Value = "Name";
        wsMentors.Cell(1, 2).Value = "Email";
        wsMentors.Cell(1, 3).Value = "Career area";
        var r = 2;
        foreach (var m in mentors)
        {
            wsMentors.Cell(r, 1).Value = m.Name;
            wsMentors.Cell(r, 2).Value = m.Email;
            wsMentors.Cell(r, 3).Value = m.CareerArea ?? "";
            r++;
        }
        wsMentors.Columns().AdjustToContents();

        var wsMentees = wb.Worksheets.Add("Unmatched mentees");
        wsMentees.Cell(1, 1).Value = "Name";
        wsMentees.Cell(1, 2).Value = "Course";
        wsMentees.Cell(1, 3).Value = "Faculty";
        r = 2;
        foreach (var m in mentees)
        {
            wsMentees.Cell(r, 1).Value = m.Name;
            wsMentees.Cell(r, 2).Value = m.Course;
            wsMentees.Cell(r, 3).Value = m.Faculty ?? "";
            r++;
        }
        wsMentees.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    // Mailchimp-compatible CSV: header row Email Address, First Name, Last Name
    public byte[] WriteMailchimpCsv(IEnumerable<Mentor> mentors)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Email Address,First Name,Last Name");
        foreach (var m in mentors)
        {
            var parts = m.Name.Split(' ', 2);
            var first = Csv(parts[0]);
            var last = Csv(parts.Length > 1 ? parts[1] : "");
            sb.AppendLine($"{Csv(m.Email)},{first},{last}");
        }
        return System.Text.Encoding.UTF8.GetBytes(sb.ToString());

        static string Csv(string v) => v.Contains(',') ? $"\"{v.Replace("\"", "\"\"")}\"" : v;
    }
}
