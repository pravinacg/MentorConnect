namespace MentorMatch.Api.Models;

public class MatchingCycle
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = default!;          // e.g. "2026 Cohort"
    public DateTimeOffset OpensAt { get; set; }
    public DateTimeOffset ClosesAt { get; set; }
}

public class Mentor
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Email { get; set; } = default!;           // matches the Entra guest's email claim
    public string Name { get; set; } = default!;
    public string? ContactPhone { get; set; }
    public string? CareerArea { get; set; }
    public string? Bio { get; set; }
    public Guid CycleId { get; set; }
    public MatchingCycle Cycle { get; set; } = default!;
    public bool IsActive { get; set; } = true;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    public ICollection<MentorCategory> Categories { get; set; } = new List<MentorCategory>();
    public ICollection<Match> Matches { get; set; } = new List<Match>();
}

public class Mentee
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = default!;
    public string Course { get; set; } = default!;
    public string? Faculty { get; set; }
    public string? Email { get; set; }                      // staff-visible only, never sent to mentors at browse time
    public string? Bio { get; set; }
    public Guid CycleId { get; set; }
    public MatchingCycle Cycle { get; set; } = default!;
    public bool IsEligible { get; set; } = false;            // false until Careers Service approves
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    public ICollection<MenteeCategory> Categories { get; set; } = new List<MenteeCategory>();

    // A mentee can have multiple match rows over time (e.g. one withdrawn, then a
    // new confirmed one). "At most one non-withdrawn" is enforced by the filtered
    // unique index in AppDbContext, not by a one-to-one navigation.
    public ICollection<Match> Matches { get; set; } = new List<Match>();
}

public class Category
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = default!;

    public ICollection<MentorCategory> MentorCategories { get; set; } = new List<MentorCategory>();
    public ICollection<MenteeCategory> MenteeCategories { get; set; } = new List<MenteeCategory>();
}

public class MentorCategory
{
    public Guid MentorId { get; set; }
    public Mentor Mentor { get; set; } = default!;
    public Guid CategoryId { get; set; }
    public Category Category { get; set; } = default!;
}

public class MenteeCategory
{
    public Guid MenteeId { get; set; }
    public Mentee Mentee { get; set; } = default!;
    public Guid CategoryId { get; set; }
    public Category Category { get; set; } = default!;
}

public class Match
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MentorId { get; set; }
    public Mentor Mentor { get; set; } = default!;
    public Guid MenteeId { get; set; }
    public Mentee Mentee { get; set; } = default!;
    public string Status { get; set; } = "confirmed";        // confirmed | withdrawn | reassigned
    public DateTimeOffset MatchedAt { get; set; } = DateTimeOffset.UtcNow;
}

// Single audit trail for all data actions. Authentication auditing (sign-ins,
// MFA results, failures) lives in Entra ID's own sign-in logs -- this table
// covers what happens INSIDE the app after a valid token arrives.
public class ActionAuditLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string PerformedBy { get; set; } = default!;      // email/UPN from the validated token
    public string ActionType { get; set; } = default!;       // mentee_upload | mentor_upload | mentee_approved | mentee_selected | match_withdrawn | report_downloaded
    public Guid? TargetId { get; set; }
    public string? Detail { get; set; }
    public string? IpAddress { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
