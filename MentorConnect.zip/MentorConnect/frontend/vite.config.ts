import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // During dev, forward /auth and /api calls to the ASP.NET Core backend
      // so the browser never has to deal with cross-origin cookies directly.
      '/auth': 'https://localhost:5001',
      '/api': 'https://localhost:5001',
    },
  },
});
