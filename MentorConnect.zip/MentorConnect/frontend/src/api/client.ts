// Centralized fetch wrapper -- always sends the session cookie ("credentials: include")
// so the httpOnly cookie set by /auth/verify is attached automatically on every call.

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`Request failed: ${res.status}`);
  }

  return res.json() as Promise<T>;
}

export async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(path, { credentials: 'include' });

  if (res.status === 401) {
    // Session expired or window closed -- send them back to request a new link
    window.location.href = '/request-link';
    throw new Error('Unauthorized');
  }

  if (!res.ok) {
    throw new Error(`Request failed: ${res.status}`);
  }

  return res.json() as Promise<T>;
}
