import { useEffect, useState } from 'react';
import { apiGet } from '../api/client';

interface MenteeProfile {
  id: string;
  name: string;
  areaOfStudy: string;
  bio: string;
}

export default function MenteeSearch() {
  const [mentees, setMentees] = useState<MenteeProfile[]>([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    // apiGet automatically redirects to /request-link on a 401,
    // so no separate "am I logged in" check is needed here.
    apiGet<MenteeProfile[]>(`/api/mentees?search=${encodeURIComponent(query)}`)
      .then(setMentees)
      .catch(() => {});
  }, [query]);

  return (
    <div>
      <h1>Browse mentees</h1>
      <input
        placeholder="Filter by area of study or keyword"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <ul>
        {mentees.map((m) => (
          <li key={m.id}>
            <strong>{m.name}</strong> — {m.areaOfStudy}
            <p>{m.bio}</p>
            <button onClick={() => selectMentee(m.id)}>Select as mentee</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

async function selectMentee(menteeId: string) {
  // Backend enforces the row-level lock in a single transaction --
  // the client just calls the endpoint and surfaces the result.
  const res = await fetch(`/api/mentees/${menteeId}/select`, {
    method: 'POST',
    credentials: 'include',
  });
  if (res.status === 409) {
    alert('This mentee was just selected by another mentor. Please choose someone else.');
  }
}
