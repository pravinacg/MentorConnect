import { useState } from 'react';
import { apiPost } from '../api/client';

export default function RequestLink() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiPost('/auth/request-link', { email });
      setSubmitted(true); // same message regardless of whether the email matched
    } catch {
      setError('Something went wrong. Please try again.');
    }
  }

  if (submitted) {
    return (
      <div>
        <h1>Check your email</h1>
        <p>If this email is registered as a mentor, a sign-in link has been sent.</p>
      </div>
    );
  }

  return (
    <div>
      <h1>Mentor sign-in</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="email">Your email address</label>
        <input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit">Send me a link</button>
      </form>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
