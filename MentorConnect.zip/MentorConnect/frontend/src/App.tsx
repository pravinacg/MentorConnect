import { BrowserRouter, Routes, Route } from 'react-router-dom';
import RequestLink from './pages/RequestLink';
import MenteeSearch from './pages/MenteeSearch';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/request-link" element={<RequestLink />} />
        <Route path="/mentee-search" element={<MenteeSearch />} />
      </Routes>
    </BrowserRouter>
  );
}
