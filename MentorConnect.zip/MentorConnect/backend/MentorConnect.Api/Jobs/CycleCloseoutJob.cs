using Microsoft.EntityFrameworkCore;
using MentorConnect.Api.Data;

namespace MentorConnect.Api.Jobs;

// Runs on Hangfire's schedule (registered in Program.cs) instead of an external
// cron job / Windows Task Scheduler entry -- keeps the "close the window" logic
// inside the app and visible in the Hangfire dashboard alongside email jobs.
public class CycleCloseoutJob
{
    private readonly ApplicationDbContext _db;

    public CycleCloseoutJob(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task Run()
    {
        var now = DateTimeOffset.UtcNow;

        // Deactivate mentors whose cycle has closed -- belt-and-braces alongside
        // the hard_expires_at check already enforced on every session read.
        await _db.Mentors
            .Where(m => m.Cycle.ClosesAt < now && m.IsActive)
            .ExecuteUpdateAsync(setters => setters.SetProperty(m => m.IsActive, false));

        // Clean up spent/expired auth artifacts
        await _db.Sessions.Where(s => s.HardExpiresAt < now).ExecuteDeleteAsync();
        await _db.MagicLinkTokens.Where(t => t.ExpiresAt < now && t.UsedAt == null).ExecuteDeleteAsync();
    }
}
