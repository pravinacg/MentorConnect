using Microsoft.EntityFrameworkCore;
using MentorConnect.Api.Models;

namespace MentorConnect.Api.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Mentor> Mentors => Set<Mentor>();
    public DbSet<Mentee> Mentees => Set<Mentee>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<MentorCategory> MentorCategories => Set<MentorCategory>();
    public DbSet<MenteeCategory> MenteeCategories => Set<MenteeCategory>();
    public DbSet<Match> Matches => Set<Match>();
    public DbSet<MatchingCycle> MatchingCycles => Set<MatchingCycle>();
    public DbSet<MagicLinkToken> MagicLinkTokens => Set<MagicLinkToken>();
    public DbSet<MentorSession> Sessions => Set<MentorSession>();
    public DbSet<AuthAuditLog> AuthAuditLogs => Set<AuthAuditLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Mentor>()
            .HasIndex(m => m.Email)
            .IsUnique();

        modelBuilder.Entity<MagicLinkToken>()
            .HasIndex(t => t.TokenHash);

        modelBuilder.Entity<MentorSession>()
            .HasIndex(s => s.SessionHash);

        modelBuilder.Entity<Mentor>()
            .HasOne(m => m.Cycle)
            .WithMany()
            .HasForeignKey(m => m.CycleId);

        modelBuilder.Entity<Mentee>()
            .HasOne(m => m.Cycle)
            .WithMany()
            .HasForeignKey(m => m.CycleId);

        // Composite keys for the many-to-many junction tables
        modelBuilder.Entity<MentorCategory>()
            .HasKey(mc => new { mc.MentorId, mc.CategoryId });

        modelBuilder.Entity<MenteeCategory>()
            .HasKey(mc => new { mc.MenteeId, mc.CategoryId });

        // A mentee can have at most one match row -- enforced with a unique index,
        // not just the one-to-one navigation, so the database itself rejects a
        // second concurrent insert even under a race condition.
        modelBuilder.Entity<Match>()
            .HasIndex(m => m.MenteeId)
            .IsUnique();

        modelBuilder.Entity<Match>()
            .HasOne(m => m.Mentor)
            .WithMany(mentor => mentor.Matches)
            .HasForeignKey(m => m.MentorId);

        modelBuilder.Entity<Match>()
            .HasOne(m => m.Mentee)
            .WithOne(mentee => mentee.Match)
            .HasForeignKey<Match>(m => m.MenteeId);
    }
}
