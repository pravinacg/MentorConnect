namespace MentorConnect.Api.Services;

public interface IEmailService
{
    Task SendMagicLinkAsync(string toEmail, string link, int ttlMinutes);
}

// Since the university is on Microsoft 365, send via Microsoft Graph rather than raw SMTP --
// avoids managing separate mail credentials and keeps sending inside the the university tenant.
public class GraphEmailService : IEmailService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _config;

    public GraphEmailService(HttpClient httpClient, IConfiguration config)
    {
        _httpClient = httpClient;
        _config = config;
    }

    public async Task SendMagicLinkAsync(string toEmail, string link, int ttlMinutes)
    {
        var senderMailbox = _config["Graph:SenderMailbox"]; // e.g. mentoring-noreply@yourorg.example

        var payload = new
        {
            message = new
            {
                subject = "Your mentoring portal access link",
                body = new
                {
                    contentType = "Text",
                    content =
                        $"Click to access the mentoring portal: {link}\n" +
                        $"This link expires in {ttlMinutes} minutes and can only be used once.\n" +
                        "Didn't request this? No action needed, but you can let us know."
                },
                toRecipients = new[] { new { emailAddress = new { address = toEmail } } }
            },
            saveToSentItems = false
        };

        // Assumes an already-configured, token-acquiring HttpClient (app-only Graph auth,
        // client credentials flow, Mail.Send permission scoped to the sender mailbox only).
        var response = await _httpClient.PostAsJsonAsync(
            $"https://graph.microsoft.com/v1.0/users/{senderMailbox}/sendMail", payload);

        response.EnsureSuccessStatusCode();
    }
}
