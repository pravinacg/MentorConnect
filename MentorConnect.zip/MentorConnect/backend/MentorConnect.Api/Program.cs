using Hangfire;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using MentorConnect.Api.Data;
using MentorConnect.Api.Endpoints;
using MentorConnect.Api.Jobs;
using MentorConnect.Api.Services;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// --- Database (Azure SQL / SQL Server) ---
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

// --- Email (Microsoft Graph, since the university is an M365 tenant) ---
builder.Services.AddHttpClient<IEmailService, GraphEmailService>();
// In production, add an HttpClientHandler/DelegatingHandler here that acquires
// a Graph app-only token via client credentials flow (MSAL.NET) and attaches it
// as a Bearer header before each request.

// --- Hangfire: background jobs for email sending and the cycle close-out job.
// Uses the same SQL Server database as the app -- no separate infra to stand up. ---
builder.Services.AddHangfire(config => config
    .UseSqlServerStorage(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddHangfireServer();
builder.Services.AddScoped<CycleCloseoutJob>();

// --- Rate limiting on the request-link endpoint ---
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("request-link", opt =>
    {
        opt.PermitLimit = 5;
        opt.Window = TimeSpan.FromHours(1);
        opt.QueueLimit = 0;
    });
});

// --- CORS: only the React app's origin, only during separate dev; in production
// the React build is served from the same origin as the API (see deployment notes) ---
builder.Services.AddCors(options =>
{
    options.AddPolicy("ReactDev", policy =>
        policy.WithOrigins(builder.Configuration["App:DevClientUrl"] ?? "http://localhost:5173")
              .AllowCredentials()
              .AllowAnyHeader()
              .AllowAnyMethod());
});

var app = builder.Build();

app.UseHttpsRedirection();
app.UseRateLimiter();

if (app.Environment.IsDevelopment())
    app.UseCors("ReactDev");

app.MapAuthEndpoints();

// Hangfire dashboard -- lock this down to staff/admin auth before internet exposure.
// For now it inherits ASP.NET Core auth; add [Authorize] filters or IP restriction
// once the staff SSO piece (Entra ID) is wired up.
app.MapHangfireDashboard("/jobs");

// Recurring job replaces the external cron/Task Scheduler entry from the
// original deployment plan -- runs daily, visible in the /jobs dashboard.
RecurringJob.AddOrUpdate<CycleCloseoutJob>(
    "close-expired-cycles",
    job => job.Run(),
    Cron.Daily);

// In production, serve the built React app as static files from the same host:
if (!app.Environment.IsDevelopment())
{
    app.UseDefaultFiles();
    app.UseStaticFiles();
    app.MapFallbackToFile("index.html");
}

app.Run();
