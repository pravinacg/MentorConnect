using System.Security.Cryptography;
using System.Text;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using MentorConnect.Api.Data;
using MentorConnect.Api.Services;

namespace MentorConnect.Api.Endpoints;

// Minimal API endpoints grouped in an extension method -- keeps Program.cs clean
// even as endpoint count grows, without needing a Controller class.
public static class AuthEndpoints
{
    private const int TokenTtlMinutes = 20;
    private const int SessionIdleHours = 4;

    public static void MapAuthEndpoints(this WebApplication app)
    {
        var auth = app.MapGroup("/auth");

        auth.MapPost("/request-link", RequestLink)
            .RequireRateLimiting("request-link");

        auth.MapGet("/verify", Verify);
    }

    public record RequestLinkBody(string Email);

    private static async Task<IResult> RequestLink(
        RequestLinkBody body,
        ApplicationDbContext db,
        IConfiguration config,
        HttpContext ctx)
    {
        var ip = ctx.Connection.RemoteIpAddress?.ToString();

        var mentor = await db.Mentors
            .Include(m => m.Cycle)
            .FirstOrDefaultAsync(m =>
                m.Email.ToLower() == body.Email.ToLower()
                && m.IsActive
                && m.Cycle.ClosesAt > DateTimeOffset.UtcNow);

        db.AuthAuditLogs.Add(new()
        {
            EmailAttempted = body.Email,
            EventType = "link_requested",
            IpAddress = ip
        });

        if (mentor != null)
        {
            var rawToken = GenerateToken();
            var tokenHash = Hash(rawToken);

            db.MagicLinkTokens.Add(new()
            {
                MentorId = mentor.Id,
                TokenHash = tokenHash,
                ExpiresAt = DateTimeOffset.UtcNow.AddMinutes(TokenTtlMinutes),
                RequestedIp = ip
            });

            await db.SaveChangesAsync();

            var appUrl = config["App:PublicUrl"];
            var link = $"{appUrl}/auth/verify?token={rawToken}";

            // Enqueue rather than await: the mentor's request returns immediately,
            // and Hangfire retries automatically (default: 10 attempts, backing off)
            // if Microsoft Graph is briefly unavailable -- the token is already
            // saved, so a delayed email doesn't lose anything.
            BackgroundJob.Enqueue<IEmailService>(e => e.SendMagicLinkAsync(mentor.Email, link, TokenTtlMinutes));
        }
        else
        {
            await db.SaveChangesAsync();
        }

        // Identical response whether or not the email matched -- prevents enumeration
        return Results.Ok(new { message = "If this email is registered, a link has been sent." });
    }

    private static async Task<IResult> Verify(
        string token,
        ApplicationDbContext db,
        IConfiguration config,
        HttpContext ctx)
    {
        if (string.IsNullOrEmpty(token))
            return Results.BadRequest("Missing token.");

        var tokenHash = Hash(token);

        // Atomic fetch-and-burn -- ExecuteUpdateAsync issues one UPDATE ... WHERE ...
        // at the database level, preventing a race where the same token verifies twice.
        var rowsAffected = await db.MagicLinkTokens
            .Where(t => t.TokenHash == tokenHash && t.UsedAt == null && t.ExpiresAt > DateTimeOffset.UtcNow)
            .ExecuteUpdateAsync(setters => setters.SetProperty(t => t.UsedAt, DateTimeOffset.UtcNow));

        if (rowsAffected == 0)
        {
            db.AuthAuditLogs.Add(new()
            {
                EventType = "link_rejected",
                IpAddress = ctx.Connection.RemoteIpAddress?.ToString()
            });
            await db.SaveChangesAsync();
            return Results.Unauthorized();
        }

        var record = await db.MagicLinkTokens.FirstAsync(t => t.TokenHash == tokenHash);
        var mentor = await db.Mentors.Include(m => m.Cycle).FirstAsync(m => m.Id == record.MentorId);

        var rawSession = GenerateToken();
        var sessionHash = Hash(rawSession);

        db.Sessions.Add(new()
        {
            MentorId = mentor.Id,
            SessionHash = sessionHash,
            IdleExpiresAt = DateTimeOffset.UtcNow.AddHours(SessionIdleHours),
            HardExpiresAt = mentor.Cycle.ClosesAt   // session can never outlive the matching window
        });

        db.AuthAuditLogs.Add(new()
        {
            EventType = "link_verified",
            IpAddress = ctx.Connection.RemoteIpAddress?.ToString()
        });

        await db.SaveChangesAsync();

        ctx.Response.Cookies.Append("session", rawSession, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict
        });

        return Results.Redirect($"{config["App:PublicUrl"]}/mentee-search");
    }

    private static string GenerateToken() =>
        Convert.ToHexString(RandomNumberGenerator.GetBytes(32));

    private static string Hash(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));
}
