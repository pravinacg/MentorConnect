namespace MentorConnect.Api.Models;

public class MatchingCycle
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = default!;      // e.g. "2026 Spring Cohort"
    public DateTimeOffset OpensAt { get; set; }
    public DateTimeOffset ClosesAt { get; set; }
}

public class Mentor
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Email { get; set; } = default!;       // matched case-insensitively at query time
    public string Name { get; set; } = default!;
    public string? Bio { get; set; }
    public Guid CycleId { get; set; }
    public MatchingCycle Cycle { get; set; } = default!;
    public bool IsActive { get; set; } = true;           // flipped false by the close-out job
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    public ICollection<MentorCategory> Categories { get; set; } = new List<MentorCategory>();
    public ICollection<Match> Matches { get; set; } = new List<Match>();
}

public class Mentee
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = default!;
    public string Course { get; set; } = default!;
    public string? Bio { get; set; }
    public Guid CycleId { get; set; }
    public MatchingCycle Cycle { get; set; } = default!;
    public bool IsEligible { get; set; } = true;         // set by Careers Service after review
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    public ICollection<MenteeCategory> Categories { get; set; } = new List<MenteeCategory>();

    // A mentee can only ever have one active match at a time -- enforced at the
    // application layer (the row-lock on selection), not by this navigation alone.
    public Match? Match { get; set; }
}

// Shared taxonomy both mentors and mentees tag against -- e.g. "Engineering",
// "Marketing", "Data science". Confirm the actual list with Careers/Alumni Office;
// this table is deliberately just a flat lookup so adding a new tag is a data
// change, not a schema change.
public class Category
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = default!;

    public ICollection<MentorCategory> MentorCategories { get; set; } = new List<MentorCategory>();
    public ICollection<MenteeCategory> MenteeCategories { get; set; } = new List<MenteeCategory>();
}

public class MentorCategory
{
    public Guid MentorId { get; set; }
    public Mentor Mentor { get; set; } = default!;
    public Guid CategoryId { get; set; }
    public Category Category { get; set; } = default!;
}

public class MenteeCategory
{
    public Guid MenteeId { get; set; }
    public Mentee Mentee { get; set; } = default!;
    public Guid CategoryId { get; set; }
    public Category Category { get; set; } = default!;
}

// A confirmed pairing. Deliberately its own table rather than a flag on Mentee --
// this is what lets a match be withdrawn/reassigned later (the post-match
// breakdown scenario) without destroying the historical record of it happening.
public class Match
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MentorId { get; set; }
    public Mentor Mentor { get; set; } = default!;
    public Guid MenteeId { get; set; }
    public Mentee Mentee { get; set; } = default!;
    public string Status { get; set; } = "confirmed";    // confirmed | withdrawn | reassigned
    public DateTimeOffset MatchedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class MagicLinkToken
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MentorId { get; set; }
    public string TokenHash { get; set; } = default!;    // SHA-256 hex digest, never the raw token
    public DateTimeOffset ExpiresAt { get; set; }
    public DateTimeOffset? UsedAt { get; set; }           // null until consumed, set once
    public string? RequestedIp { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class MentorSession
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MentorId { get; set; }
    public string SessionHash { get; set; } = default!;
    public DateTimeOffset IdleExpiresAt { get; set; }
    public DateTimeOffset HardExpiresAt { get; set; }     // = cycle.ClosesAt, never extended past this
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public class AuthAuditLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string? EmailAttempted { get; set; }
    public string EventType { get; set; } = default!;     // link_requested | link_verified | link_rejected
    public string? IpAddress { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
