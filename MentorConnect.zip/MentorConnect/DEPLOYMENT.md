# Deployment Requirements — Mentor/Mentee Portal (ASP.NET Core + React)

## 1. Runtime requirements

| Component | Requirement |
|---|---|
| Backend | .NET 8 (LTS) runtime |
| Frontend build | Node.js 20 LTS (build-time only — not needed at runtime, since React compiles to static files) |
| Database | SQL Server 2019+ or Azure SQL Database |
| Reverse proxy / TLS termination | IIS with ASP.NET Core Module, or Nginx, or Azure App Service's built-in front end |

## 2. Two realistic hosting paths

### Option A — Azure App Service (recommended, lowest ops overhead)
- One **App Service** (Linux or Windows) running the ASP.NET Core API, with the built React app's static files served from the same app (`wwwroot`) — this avoids a second hosting cost and avoids CORS entirely in production, since frontend and backend share an origin.
- **Azure SQL Database** (Basic/Standard tier is enough for this scale) for the schema described earlier.
- **Azure Key Vault** for secrets (SQL connection string, Graph app registration client secret) — referenced via App Service's Key Vault integration rather than stored in `appsettings.json`.
- **Managed Identity** on the App Service so it authenticates to Azure SQL and Key Vault without embedding credentials at all.
- **Application Insights** for logging/monitoring — picks up unhandled exceptions and request telemetry with minimal setup.
- TLS handled automatically by Azure's front door; just bind the university's custom domain and certificate (or use App Service Managed Certificates).

### Option B — On-premises IIS (if the university requires on-prem hosting)
- Windows Server with IIS + the **ASP.NET Core Hosting Bundle** installed.
- SQL Server instance reachable from the IIS server (existing the university SQL Server infrastructure, if available).
- A certificate from the university's internal CA (or a public cert if internet-facing) bound in IIS for HTTPS.
- Secrets via **appsettings.Production.json protected with `dotnet user-secrets`/DPAPI**, or an on-prem secrets vault if the university has one — avoid plaintext secrets in the deployed config file.
- A scheduled task (Windows Task Scheduler, not just relying on the app's own background timer) to run the cycle close-out job as a redundant safety net.

## 3. Network / firewall requirements

- Inbound HTTPS (443) only, from the internet, for the mentor-facing paths (`/request-link`, `/auth/verify`, `/mentee-search`).
- Admin/upload endpoints (Careers/Alumni staff) should sit behind the university's VPN or be restricted to the university's IP ranges at the firewall/App Service access-restriction level, in addition to requiring the university SSO — defense in depth, not either/or.
- Outbound HTTPS to `graph.microsoft.com` (443) for sending mentor emails via Microsoft Graph.
- Outbound to Azure SQL / on-prem SQL Server on 1433 (or your DBA's configured port).

## 4. Identity / auth configuration needed before go-live

- An **Azure AD app registration** in the university's tenant with `Mail.Send` application permission (admin-consented), scoped if possible to only the mentoring-noreply mailbox via application access policy — not tenant-wide mail send.
- If integrating staff SSO: register a second app registration (or reuse an existing the university one) for the **Careers/Alumni admin login**, using the standard OpenID Connect flow with MFA enforced at the tenant conditional access policy level, not the app level.

## 5. CI/CD pipeline (GitHub Actions or Azure DevOps — either works with this stack)

1. **Build** — `dotnet build` for the API, `npm ci && npm run build` for the React app.
2. **Test** — run backend unit/integration tests against a throwaway SQL container (e.g. via `mcr.microsoft.com/mssql/server` Docker image in the pipeline).
3. **Package** — copy the React `dist/` output into the API's `wwwroot` folder before publishing, so the API deploys as one self-contained artifact.
4. **Deploy** — `dotnet publish` → deploy to App Service (via `azure/webapps-deploy` GitHub Action) or `robocopy`/IIS deployment for on-prem.
5. **Migrate** — run `dotnet ef database update` as a pipeline step against the target environment, gated behind manual approval for production.

## 6. Environment-specific config checklist

- [ ] Connection string per environment (dev/staging/prod), never shared
- [ ] `App:PublicUrl` set correctly per environment (used to build magic-link URLs — a wrong value here silently breaks every login email)
- [ ] Graph tenant/client IDs per environment if using separate dev/prod app registrations
- [ ] Cookie `Secure` flag requires HTTPS in **every** environment including dev, or the cookie silently won't be set — use `dotnet dev-certs https --trust` locally

## 7. Ongoing operational requirements

- A scheduled job (Azure Function on a timer trigger, or the on-prem Task Scheduler equivalent) to run the cycle close-out logic daily.
- Log retention policy for `auth_audit_log` — define how long the university wants to retain login attempt history, consistent with the GDPR retention conversation already underway with your DPO.
- Monitoring alert on repeated `link_rejected` events from a single IP — early signal of someone probing the endpoint.
